import * as React from "react";
import { useState, useRef } from "react";
import { PrimaryButton } from "@fluentui/react";

const FileUpload = () => {};

const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {};

const onButtonClick = () => {};

export default function FileMenuComponent(props: any) {
	return (
		<>
			<PrimaryButton text="Open File" />
		</>
	);
}

import * as React from "react";
import { Label } from "@fluentui/react";
import FileMenuComponent from "./FileMenuComponent";
import PDFViewerComponent from "./PDFViewerComponent";

export interface IHomeProps {
	name?: string;
}

export class HomeComponent extends React.Component<IHomeProps> {
	public render(): React.ReactNode {
		return (
			<>
				<FileMenuComponent />
				<PDFViewerComponent document={this.props.name} />
			</>
		);
	}
}
